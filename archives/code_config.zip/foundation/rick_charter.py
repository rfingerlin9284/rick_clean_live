#!/usr/bin/env python3
"""
RICK Charter Enforcement Module - RBOTzilla UNI Phase 2
Immutable trading constants and enforcement logic.
PIN: 841921 | Generated: 2025-09-26
"""

import logging
from typing import Dict, List, Optional, Union
from datetime import timedelta
from enum import Enum

class TimeFrame(Enum):
    """Allowed trading timeframes"""
    M15 = "M15"
    M30 = "M30"
    H1 = "H1"
    
class RejectedTimeFrame(Enum):
    """Explicitly rejected timeframes"""
    M1 = "M1"
    M5 = "M5"

class RickCharter:
    """
    RICK Charter Core Enforcement - Immutable Constants
    All values are hardcoded for safety and cannot be overridden.
    """
    
    # CORE AUTHENTICATION
    PIN = 841921
    CHARTER_VERSION = "2.0_IMMUTABLE"
    
    # TRADING CONSTRAINTS
    MAX_HOLD_DURATION_HOURS = 6
    MAX_HOLD_DURATION = timedelta(hours=MAX_HOLD_DURATION_HOURS)
    
    # =========================================================================
    # INCOME GOAL & SMART AGGRESSION STRATEGY (PIN 841921)
    # User Goal: $600/day income using $2K initial + $1K/month deposits
    # Strategy: Bootstrap → Scale → Automate (AI hive-driven)
    # =========================================================================
    
    # INCOME TARGETS (IMMUTABLE - AI-driven with smart aggression)
    DAILY_INCOME_TARGET_USD = 600.00  # Daily profit target
    MONTHLY_INCOME_TARGET_USD = 12600.00  # 21 trading days × $600
    ANNUAL_INCOME_TARGET_USD = 151200.00  # 252 trading days × $600
    DAILY_RISK_PER_TRADE = 0.02  # 2% risk per trade (immutable)
    
    # BOOTSTRAP PHASE (Month 0-3): Prove system works on small capital
    BOOTSTRAP_PHASE_CAPITAL_START_USD = 2000.00
    BOOTSTRAP_PHASE_CAPITAL_END_USD = 5300.00  # After deposits + P&L
    BOOTSTRAP_PHASE_DAILY_TARGET_USD = 100.00  # Start small, prove win rate
    BOOTSTRAP_PHASE_MIN_WIN_RATE = 0.60  # 60% win rate target
    BOOTSTRAP_PHASE_TRADES_PER_DAY = 5  # 3-5 trades for ML pattern testing
    
    # SCALE PHASE (Month 3-6): Double daily income with position scaling
    SCALE_PHASE_CAPITAL_START_USD = 5300.00
    SCALE_PHASE_CAPITAL_END_USD = 15000.00  # Target: reach no-leverage zone
    SCALE_PHASE_DAILY_TARGET_USD = 300.00  # Scale to 3x bootstrap income
    SCALE_PHASE_MIN_WIN_RATE = 0.60  # Maintain win rate
    SCALE_PHASE_POSITION_SCALE_FACTOR = 2.5  # Scale positions with capital
    
    # AGGRESSIVE PHASE (Month 6-12): Hit full $600/day target
    AGGRESSIVE_PHASE_CAPITAL_START_USD = 15000.00
    AGGRESSIVE_PHASE_CAPITAL_END_USD = 25000.00  # Organic growth
    AGGRESSIVE_PHASE_DAILY_TARGET_USD = 600.00  # FULL TARGET
    AGGRESSIVE_PHASE_MIN_WIN_RATE = 0.60  # Maintain consistency
    AGGRESSIVE_PHASE_CONCURRENT_POSITIONS = 3  # Run 2-4 positions simultaneously
    AGGRESSIVE_PHASE_LEVERAGE_MAX = 3.0  # 3x max (safer with bigger capital)
    
    # AUTOMATION PHASE (Month 12+): Sustain $600+/day via bots
    AUTOMATION_PHASE_CAPITAL_START_USD = 25000.00
    AUTOMATION_PHASE_DAILY_TARGET_USD = 1000.00  # Scale beyond $600/day
    AUTOMATION_PHASE_BOT_TRIGGER_WIN_RATE = 0.65  # Only automate proven patterns
    AUTOMATION_PHASE_LEVERAGE_MAX = 1.0  # No leverage needed at scale
    
    # MONTHLY CAPITAL ADDITIONS (IMMUTABLE)
    MONTHLY_DEPOSIT_USD = 1000.00  # $1K/month automatic deposits
    
    # =========================================================================
    # SECTION 12: BROKER & GATEWAY CONFIGURATION (PIN 841921)
    # Approved: 2025-10-19
    # IMMUTABLE: All broker connectivity is hardcoded for safety
    # =========================================================================
    
    # BROKER ENDPOINTS (IMMUTABLE)
    OANDA_ENVIRONMENT_CANARY = "practice"  # Paper/practice account
    OANDA_ENVIRONMENT_LIVE = "live"  # Real money account
    OANDA_ENABLED = True  # IMMUTABLE
    OANDA_TRADING_PAIRS = ["EUR/USD", "GBP/USD", "XAU/USD"]  # IMMUTABLE forex pairs
    OANDA_DAILY_CAPITAL_USD = 2500.00  # $2.5K allocation
    
    # IBKR GATEWAY CONFIGURATION (IMMUTABLE)
    IBKR_GATEWAY_ENABLED = True  # IMMUTABLE
    IBKR_GATEWAY_HOST = "172.25.80.1"  # IMMUTABLE: Windows host IP from WSL
    IBKR_GATEWAY_PORT = 7497  # IMMUTABLE: IB Gateway socket port
    IBKR_GATEWAY_CLIENT_ID = 1  # IMMUTABLE: Client connection ID
    IBKR_GATEWAY_TIMEOUT_SECONDS = 30  # IMMUTABLE: Connection timeout
    IBKR_PAPER_TRADING_ENABLED = True  # IMMUTABLE: Use paper account
    IBKR_TRADING_CONTRACTS = ["BTC-PERP", "ETH-PERP"]  # IMMUTABLE: Crypto futures
    IBKR_DAILY_CAPITAL_USD = 2000.00  # $2K allocation
    
    # BROKER STARTUP VALIDATION (IMMUTABLE)
    BROKER_VALIDATION_REQUIRED = True  # IMMUTABLE: Must pass before trading
    BROKER_VALIDATION_TIMEOUT_SECONDS = 10  # IMMUTABLE: Connection test timeout
    BROKER_VALIDATION_RETRY_ATTEMPTS = 3  # IMMUTABLE: Retry failed connections 3x
    
    # BROKER FAILURE HANDLING (IMMUTABLE)
    BROKER_CONNECTION_FAILURE_ACTION = "HALT"  # IMMUTABLE: Stop trading if connection lost
    BROKER_RECONNECTION_ATTEMPTS = 5  # IMMUTABLE: Try to reconnect 5 times
    BROKER_RECONNECTION_BACKOFF_SECONDS = 10  # IMMUTABLE: Exponential backoff
    
    # AI HIVE CONFIGURATION (for autonomous trading with smart aggression)
    AI_HIVE_MEMBERS = ["RICK", "GPT", "Deepseek", "Github", "Grok"]
    AI_HIVE_ENABLED = True  # Autonomous trading hive
    AI_HIVE_VOTE_CONSENSUS = 0.80  # 80% consensus required for aggressive trades
    AI_HIVE_PATTERN_CONFIDENCE_THRESHOLD = 0.75  # 75% ML confidence for entry
    AI_HIVE_LEARNING_WINDOW = 90  # Days of pattern learning in bootstrap phase
    
    # SMART AGGRESSION RULES (IMMUTABLE)
    SMART_AGGRESSION_ENABLED = True
    SMART_AGGRESSION_BOOTSTRAP_CONSERVATIVE = True  # Conservative in Phase 1
    SMART_AGGRESSION_SCALE_AGGRESSIVE = True  # Aggressive in Phase 2+
    SMART_AGGRESSION_SCALE_FACTOR_PER_PHASE = 1.5  # 1.5x aggression per phase
    
    # RISK MANAGEMENT
    DAILY_LOSS_BREAKER_PCT = -5.0  # -5% daily loss halt
    MIN_NOTIONAL_USD = 15000
    
    # Minimum risk-reward ratio (guide compliance: 3.2)
    MIN_RISK_REWARD_RATIO = 3.2
    
    # =========================================================================
    # SECTION 11: CRYPTO WIN RATE OPTIMIZATION (PIN 841921)
    # Approved: 2025-10-19
    # IMMUTABLE: 4 High-Impact Improvements for 60% → 72%+ Win Rate
    # =========================================================================
    
    """
    CRYPTO WIN RATE IMPROVEMENT STRATEGY
    Goal: Increase crypto trading win rate from 60% baseline to 72%+ through
    tighter signal filtering, volatility-aware execution, and multi-signal confirmation.
    
    Implementation: 4 immutable rules that filter lower-quality setups and
    improve execution timing in crypto markets.
    
    Expected Timeline:
    - Week 1: Implement #1 (90% hive consensus) → 65% win rate
    - Week 2: Add #2 (time windows) → 68% win rate
    - Week 3: Add #3 (volatility sizing) → 70% win rate
    - Week 4: Add #4 (confluence gates) → 72%+ win rate
    
    Combined Impact: $100-150/day → $175-250/day by Month 1
    """
    
    # =========================================================================
    # IMPROVEMENT #1: CRYPTO-SPECIFIC AI HIVE VOTING (HIGHER CONSENSUS)
    # =========================================================================
    CRYPTO_AI_HIVE_ENABLED = True  # IMMUTABLE
    CRYPTO_AI_HIVE_VOTE_CONSENSUS = 0.90  # IMMUTABLE: 90% for crypto (vs 80% forex)
    CRYPTO_HIVE_CONSENSUS_APPLIES_TO = ["BTC/USD", "ETH/USD", "BTC-PERP", "ETH-PERP"]
    FOREX_AI_HIVE_VOTE_CONSENSUS = 0.80  # IMMUTABLE: 80% for forex baseline
    
    # Rationale: Crypto is more volatile than forex
    # → Require higher consensus to filter marginal signals
    # → Only take entries where 90%+ of AI hive agree
    # → Reject setups with <90% agreement (fewer false signals, fewer whipsaws)
    
    # =========================================================================
    # IMPROVEMENT #2: TIME-BASED TRADING WINDOWS (PEAK LIQUIDITY ONLY)
    # =========================================================================
    CRYPTO_TIME_WINDOW_ENABLED = True  # IMMUTABLE
    CRYPTO_TRADE_WINDOW_START_HOUR_ET = 8  # IMMUTABLE: 8 AM ET
    CRYPTO_TRADE_WINDOW_END_HOUR_ET = 16  # IMMUTABLE: 4 PM ET (16:00)
    CRYPTO_TRADE_WINDOW_DAYS = ["MON", "TUE", "WED", "THU", "FRI"]  # IMMUTABLE: Mon-Fri only
    
    # Skip trading during:
    # - Weekend (Sat/Sun): Thin liquidity, news whipsaws
    # - Outside 8am-4pm ET: Low volume, wider spreads, overnight reversals
    # - Pre-market/After-hours: Not applicable to crypto, but enforced for consistency
    
    # Rationale: Peak crypto liquidity = 8am-4pm ET, Mon-Fri (US/Asia overlap)
    # → Avoid weekend thin trading (wider spreads, lower volume)
    # → Avoid overnight whipsaws (4pm-8am = lower volume, news-driven moves)
    # → Only trade when volume spike confirms conviction
    # → Expected: +3-7% win rate improvement (fewer choppy market false exits)
    
    # =========================================================================
    # IMPROVEMENT #3: VOLATILITY-ADJUSTED POSITION SIZING
    # =========================================================================
    CRYPTO_VOLATILITY_SIZING_ENABLED = True  # IMMUTABLE
    CRYPTO_VOLATILITY_SIZE_SCALING = True  # IMMUTABLE
    
    # Position sizing inversely related to current volatility
    # Higher volatility = smaller position (lower risk per trade)
    # Lower volatility = larger position (higher opportunity)
    
    VOLATILITY_HIGH_ATR_THRESHOLD = 2.0  # ATR > 2.0x = high volatility
    VOLATILITY_HIGH_POSITION_SCALE = 0.50  # Position size = 50% of normal
    
    VOLATILITY_NORMAL_ATR_MIN = 1.0  # ATR between 1.0x - 1.5x
    VOLATILITY_NORMAL_ATR_MAX = 1.5
    VOLATILITY_NORMAL_POSITION_SCALE = 1.0  # Position size = 100% (standard)
    
    VOLATILITY_LOW_ATR_THRESHOLD = 1.0  # ATR < 1.0x = low volatility
    VOLATILITY_LOW_POSITION_SCALE = 1.5  # Position size = 150% (capture opportunity)
    
    # Rationale: Match position size to market conditions
    # → When ATR expands (volatility spike): Reduce position to 50% (lower risk)
    # → When ATR normal (1.0-1.5x): Take normal 100% position
    # → When ATR contracts (quiet market): Increase position to 150% (higher opportunity)
    # → Expected: +2-5% win rate improvement (fewer stopped out in spikes, more wins in quiet)
    
    # =========================================================================
    # IMPROVEMENT #4: ENTRY CONFLUENCE GATES (MULTI-SIGNAL CONFIRMATION)
    # =========================================================================
    CRYPTO_CONFLUENCE_GATES_ENABLED = True  # IMMUTABLE
    CRYPTO_CONFLUENCE_SCORE_REQUIRED = 4  # IMMUTABLE: Minimum 4/5 signals required
    
    # Required signals for high-quality entry (must score >= 4/5):
    CRYPTO_CONFLUENCE_GATE_1_RSI = True  # Gate 1: RSI in healthy range (30-70, not overbought/oversold)
    CRYPTO_CONFLUENCE_GATE_2_MA = True  # Gate 2: Price above/below appropriate MA (20/50/200)
    CRYPTO_CONFLUENCE_GATE_3_VOLUME = True  # Gate 3: Volume spike (>1.5x normal confirms conviction)
    CRYPTO_CONFLUENCE_GATE_4_HIVE = True  # Gate 4: AI hive consensus >= 90% (already implemented #1)
    CRYPTO_CONFLUENCE_GATE_5_TREND = True  # Gate 5: 4-hour trend aligned with 15-min entry (confluence)
    
    # Scoring system:
    # Only take trades that pass 4 or more of these gates:
    # ✓ RSI not overbought (RSI < 70) or oversold (RSI > 30) - healthy entry zones
    # ✓ Price trading above/below key MA (trend confirmation)
    # ✓ Volume spike visible (volume > 1.5x 20-period average)
    # ✓ Hive consensus >= 90% (high conviction among AI members)
    # ✓ 4-hour trend direction matches 15-min entry direction (higher-level confirmation)
    
    # Reject trades that fail multiple gates:
    # ✗ RSI 80+ (overbought, likely to reverse)
    # ✗ Price breaking support but no volume (weak signal)
    # ✗ Hive consensus only 85% (marginal, not high conviction)
    # ✗ 15-min signal opposite 4-hour trend (counter-trend, higher risk)
    
    # Rationale: Filter out "maybe" signals, keep only highest-quality setups
    # → Expected: +5-8% win rate improvement (quality > quantity)
    # → Trades per day may decrease, but win rate increases more
    # → Example: 5 trades @ 60% = 3 wins; 3 trades @ 72% = 2.16 wins (fewer but better)
    
    # =========================================================================
    # COMBINED IMPACT SUMMARY (ALL 4 IMPROVEMENTS)
    # =========================================================================
    CRYPTO_WIN_RATE_OPTIMIZATION_PHASE = "BOOTSTRAP"  # Active in Phase 1
    CRYPTO_WIN_RATE_BASELINE = 0.60  # Current 60% baseline
    CRYPTO_WIN_RATE_TARGET_WEEK_1 = 0.65  # After #1 (90% hive)
    CRYPTO_WIN_RATE_TARGET_WEEK_2 = 0.68  # After #2 (time windows)
    CRYPTO_WIN_RATE_TARGET_WEEK_3 = 0.70  # After #3 (volatility sizing)
    CRYPTO_WIN_RATE_TARGET_WEEK_4 = 0.72  # After #4 (confluence gates)
    CRYPTO_WIN_RATE_FINAL_TARGET = 0.75  # Ultimate target after full refinement
    
    # =========================================================================
    # ENFORCEMENT: VIOLATIONS & REMEDIATION
    # =========================================================================
    """
    VIOLATION: Any trade that violates these crypto rules will be:
    1. Rejected at entry (order not placed)
    2. Logged with reason code
    3. Counted as "filtered" in daily summary
    4. NOT counted against win rate (correctly rejected trades improve true win rate)
    
    Examples of violations:
    - Crypto entry with <90% AI hive consensus → REJECTED
    - Crypto entry outside 8am-4pm ET → REJECTED
    - Crypto entry with 3/5 confluence gates only → REJECTED
    - Crypto entry when ATR > 2.0 but using 100% position size → REDUCED to 50%
    
    Non-violations (allowed):
    - Forex entry with 80% hive consensus → ALLOWED (80% gate applies to forex)
    - Crypto exit outside 8am-4pm ET → ALLOWED (time window applies to ENTRY only)
    - Crypto position held past 4pm ET → ALLOWED (existing positions not affected)
    """
    CRYPTO_RULES_ENFORCEMENT_STRICT = True  # IMMUTABLE: Hard reject vs soft warnings
    CRYPTO_VIOLATION_LOG_REQUIRED = True  # IMMUTABLE: Log all rejections
    CRYPTO_VIOLATION_REASON_CODES = [
        "INSUFFICIENT_HIVE_CONSENSUS",  # < 90% AI hive agreement
        "OUTSIDE_TRADE_WINDOW",  # Not 8am-4pm ET or not Mon-Fri
        "INSUFFICIENT_CONFLUENCE_GATES",  # < 4/5 signals confirmed
        "POSITION_SIZE_VIOLATION",  # Size doesn't match volatility tier
    ]
    
    # TIMEFRAME ENFORCEMENT
    ALLOWED_TIMEFRAMES = [TimeFrame.M15, TimeFrame.M30, TimeFrame.H1]
    REJECTED_TIMEFRAMES = [RejectedTimeFrame.M1, RejectedTimeFrame.M5]
    
    # EXECUTION LIMITS
    MAX_CONCURRENT_POSITIONS = 3
    MAX_DAILY_TRADES = 12
    MAX_PLACEMENT_LATENCY_MS = 300  # Maximum 300ms for order placement
    
    # SPREAD & SLIPPAGE GATES
    FX_MAX_SPREAD_ATR_MULTIPLIER = 0.15    # 0.15x ATR14
    CRYPTO_MAX_SPREAD_ATR_MULTIPLIER = 0.10 # 0.10x ATR14
    
    # STOP LOSS REQUIREMENTS
    FX_STOP_LOSS_ATR_MULTIPLIER = 1.2      # 1.2x ATR
    CRYPTO_STOP_LOSS_ATR_MULTIPLIER = 1.5  # 1.5x ATR
    
    # =========================================================================
    # ADDENDUM: UI/DISPLAY SEPARATION (IMMUTABLE) - Approved PIN: 841921
    # Added: 2025-10-15
    # =========================================================================
    """
    CRITICAL IMMUTABLE RULE: UI/Dashboard Display Separation
    
    The timing, execution, and logic of ALL trading decisions are determined
    EXCLUSIVELY by ML intelligence and smart logic nodes. 
    
    Dashboard, UI, and display components are for VISUALIZATION AND USER 
    PREFERENCE ONLY and shall have ZERO effect on trading timing logic.
    
    This ensures:
    1. Trading logic remains pure and unaffected by display layer
    2. UI refresh rates can be adjusted without impacting execution
    3. User preferences do not introduce latency or timing issues
    4. ML/AI decision-making operates independently of visualization
    5. Charter compliance is enforced at logic layer, not UI layer
    
    ENFORCEMENT:
    - No trading logic shall read from or depend on UI state
    - Display refresh rates are independent of trade execution timing
    - UI components operate in separate threads/processes from trading engine
    - User UI preferences stored separately from trading parameters
    - Dashboard controls are READ-ONLY views of trading state
    
    VIOLATION: Any code that ties trading timing to UI refresh rates or
    user display preferences is a CHARTER VIOLATION and must be rejected.
    """
    UI_DISPLAY_SEPARATION_ENFORCED = True
    UI_CONTROLS_TRADING_LOGIC = False  # IMMUTABLE: Must always be False
    
    # =========================================================================
    # ADDENDUM: MANDATORY CODE REUSE SWEEP (IMMUTABLE) - Approved PIN: 841921
    # Added: 2025-10-15
    # =========================================================================
    """
    CRITICAL IMMUTABLE RULE: Pre-Implementation Code Discovery
    
    Before creating ANY new code, logic, or implementation, a MANDATORY sweep
    of ALL existing project folders MUST be performed to discover and reuse
    existing implementations.
    
    REQUIRED PROJECT FOLDERS TO SEARCH (in order of priority):
    1. /home/ing/RICK/RICK_LIVE_CLEAN (current working directory)
    2. /home/ing/RICK/RBOTZILLA_FINAL_v001
    3. /home/ing/RICK/R_H_UNI
    4. /home/ing/RICK/R_H_UNI_BLOAT_ARCHIVE
    5. /home/ing/RICK/RICK_LIVE_PROTOTYPE
    6. /home/ing/RICK/Dev_unibot_v001
    7. /home/ing/RICK/Protoype [sic]
    8. /home/ing/RICK/Attached HTML and CSS Context
    
    ENFORCEMENT PROCEDURE:
    1. When ANY feature, function, or logic is requested, FIRST grep search
       all project folders for existing implementations
    2. If existing logic is found, EXTRACT and INTEGRATE it rather than
       creating new code from scratch
    3. Document the source folder and file where logic was found
    4. Preserve original author attribution and comments
    5. Only create NEW code if NO existing implementation exists
    
    SEARCH PATTERNS REQUIRED (minimum):
    - Exact function/class names mentioned in user request
    - Related feature keywords (e.g., "momentum", "trailing", "tp_cancel")
    - Similar logic patterns (e.g., regex for common implementations)
    
    VIOLATION: Creating new code without performing mandatory code reuse
    sweep is a CHARTER VIOLATION and results in:
    - Wasted development time duplicating existing work
    - Inconsistent implementations across codebase
    - Loss of battle-tested, validated logic
    - Technical debt from redundant implementations
    
    This rule ensures MAXIMUM code reuse, consistency, and preservation of
    existing validated implementations across all RICK project folders.
    """
    MANDATORY_CODE_REUSE_SWEEP_ENFORCED = True
    BYPASS_CODE_REUSE_SWEEP = False  # IMMUTABLE: Must always be False
    
    PROJECT_FOLDERS_TO_SEARCH = [
        "/home/ing/RICK/RICK_LIVE_CLEAN",
        "/home/ing/RICK/RBOTZILLA_FINAL_v001",
        "/home/ing/RICK/R_H_UNI",
        "/home/ing/RICK/R_H_UNI_BLOAT_ARCHIVE",
        "/home/ing/RICK/RICK_LIVE_PROTOTYPE",
        "/home/ing/RICK/Dev_unibot_v001",
        "/home/ing/RICK/Protoype",
        "/home/ing/RICK/Attached HTML and CSS Context"
    ]
    
    # ========================================================================
    # SECTION 8: ENVIRONMENT-AGNOSTIC ARCHITECTURE (PIN 841921)
    # Approved: 2025-10-15
    # IMMUTABLE: Single unified codebase for practice/live environments
    # ========================================================================
    
    # ENVIRONMENT DIFFERENTIATION (IMMUTABLE)
    # The ONLY difference between practice and live trading shall be:
    # 1. API endpoint URL (practice vs live)
    # 2. API authentication token
    # NO other code paths, logic, or risk rules may differ between environments
    ENVIRONMENT_AGNOSTIC_ENFORCED = True  # IMMUTABLE: Must always be True
    ALLOW_ENVIRONMENT_SPECIFIC_LOGIC = False  # IMMUTABLE: Must always be False
    
    # PRACTICE/LIVE PARITY REQUIREMENTS (IMMUTABLE)
    IDENTICAL_CHARTER_ENFORCEMENT = True  # Same rules in practice and live
    IDENTICAL_RISK_PARAMETERS = True  # Same position sizing, stops, targets
    IDENTICAL_MOMENTUM_DETECTION = True  # Same TP cancellation logic
    IDENTICAL_TRAILING_STOPS = True  # Same adaptive trailing system
    IDENTICAL_NARRATION_LOGGING = True  # Same audit trail format
    
    # CONFIGURATION LOCATION (IMMUTABLE)
    # Environment selection MUST occur ONLY in:
    # - OandaConnector.__init__(environment='practice' or 'live')
    # - Command-line argument: --env practice|live
    # NO environment checks allowed in trading logic, risk management, or strategies
    ENVIRONMENT_CONFIG_CENTRALIZED = True  # IMMUTABLE
    
    # ========================================================================
    # SECTION 9: TP CANCELLATION & MOMENTUM TRAILING (PIN 841921)
    # Approved: 2025-10-15
    # IMMUTABLE: Battle-tested logic from rbotzilla_golden_age.py
    # ========================================================================
    
    # TP CANCELLATION TRIGGERS (IMMUTABLE)
    # Take Profit orders SHALL be cancelled and converted to trailing stops when:
    # 1. Hive Mind consensus >= 80% confidence AND signal matches position direction
    #    OR
    # 2. MomentumDetector confirms strong momentum:
    #    - Profit > 1.8-2.0x ATR (lower threshold in bull markets)
    #    - Trend strength > 0.65-0.70 (lower threshold in bull markets)
    #    - Strong market cycle OR high volatility (> 1.2x normal)
    TP_CANCELLATION_ENABLED = True  # IMMUTABLE: Must always be True
    DISABLE_TP_CANCELLATION = False  # IMMUTABLE: Must always be False
    
    # DUAL-SIGNAL TRIGGERING (IMMUTABLE)
    # TP cancellation fires when EITHER Hive OR Momentum confirms
    # Provides redundancy and maximum signal confirmation
    HIVE_TRIGGER_CONFIDENCE_MIN = 0.80  # IMMUTABLE: 80% consensus minimum
    MOMENTUM_PROFIT_THRESHOLD_ATR = 1.8  # IMMUTABLE: 1.8x ATR in bull markets
    MOMENTUM_TREND_THRESHOLD = 0.65  # IMMUTABLE: 0.65 in bull markets
    MOMENTUM_VOLATILITY_THRESHOLD = 1.2  # IMMUTABLE: 1.2x normal volatility
    
    # STOP LOSS PROTECTION (IMMUTABLE)
    # Stop Loss orders SHALL NEVER be removed or disabled
    # Only Take Profit orders may be cancelled (converted to trailing stops)
    STOP_LOSS_ALWAYS_REQUIRED = True  # IMMUTABLE: SL always present
    ALLOW_STOP_LOSS_REMOVAL = False  # IMMUTABLE: Must always be False
    
    # ADAPTIVE TRAILING STOPS (IMMUTABLE)
    # Progressive tightening system from rbotzilla_golden_age.py
    # 6 levels of trailing distance based on profit ATR multiples:
    TRAILING_LEVEL_1_PROFIT = 1.0  # 0-1x ATR profit
    TRAILING_LEVEL_1_DISTANCE = 1.2  # 1.2x ATR trail
    TRAILING_LEVEL_2_PROFIT = 2.0  # 1-2x ATR profit
    TRAILING_LEVEL_2_DISTANCE = 1.0  # 1.0x ATR trail
    TRAILING_LEVEL_3_PROFIT = 3.0  # 2-3x ATR profit
    TRAILING_LEVEL_3_DISTANCE = 0.8  # 0.8x ATR trail
    TRAILING_LEVEL_4_PROFIT = 4.0  # 3-4x ATR profit
    TRAILING_LEVEL_4_DISTANCE = 0.6  # 0.6x ATR trail
    TRAILING_LEVEL_5_PROFIT = 5.0  # 4-5x ATR profit
    TRAILING_LEVEL_5_DISTANCE = 0.5  # 0.5x ATR trail
    TRAILING_LEVEL_6_DISTANCE = 0.4  # 5+x ATR profit: 0.4x ATR trail (ultra-tight)
    
    # MOMENTUM LOOSENING FACTOR (IMMUTABLE)
    # When momentum detected, trailing stops loosen by 15% to let winners run
    MOMENTUM_TRAIL_LOOSENING_FACTOR = 1.15  # IMMUTABLE: 15% loosening
    
    # CODE ORIGIN ATTRIBUTION (IMMUTABLE)
    # All momentum detection and trailing logic extracted from:
    MOMENTUM_SOURCE_FILE = "/home/ing/RICK/RICK_LIVE_CLEAN/rbotzilla_golden_age.py"
    MOMENTUM_SOURCE_LINES = "140-230"  # MomentumDetector + SmartTrailingSystem
    MOMENTUM_EXTRACTION_DATE = "2025-10-15"
    MOMENTUM_EXTRACTION_PIN = 841921  # Charter-approved extraction
    
    # POSITION AGE REQUIREMENT (IMMUTABLE)
    # Positions must be >= 60 seconds old before TP cancellation considered
    # Prevents premature conversions on entry volatility
    MIN_POSITION_AGE_FOR_TP_CANCEL_SECONDS = 60  # IMMUTABLE
    
    # ========================================================================
    # SECTION 10: DUAL-SOURCE ARCHITECTURE (PIN 841921)
    # Approved: 2025-10-16
    # IMMUTABLE: Separate live data feed from practice execution
    # ========================================================================
    
    # LIVE DATA + PRACTICE EXECUTION PATTERN (IMMUTABLE)
    # This architecture enables safe paper trading with real market prices:
    # - Live token connector: streams prices, quotes, tick data (READ-ONLY)
    # - Practice token connector: executes orders, manages positions (WRITE-ONLY)
    # 
    # Benefits:
    # 1. Real market data ensures realistic price levels
    # 2. Practice execution limits risk to paper account
    # 3. Mimics production setup: same architecture as live deployment
    # 4. Enables safe validation of trading logic before live money
    # 5. No code changes between practice and live (only env vars differ)
    DUAL_SOURCE_ARCHITECTURE_ENABLED = True  # IMMUTABLE
    
    # Data source configuration (IMMUTABLE)
    DATA_SOURCE_PREFERENCE = "live"  # Primary source for market data
    EXECUTION_SOURCE = "practice"  # Where orders are actually placed
    FALLBACK_DATA_SOURCE = "practice"  # Use practice prices if live unavailable
    
    # Pricing hierarchy (IMMUTABLE)
    # When live data unavailable, use practice prices to maintain operation
    USE_LIVE_PRICES_WHEN_AVAILABLE = True
    ALLOW_PRACTICE_FALLBACK = True
    PRICE_DATA_VALIDATION_REQUIRED = True  # Reject stale/null prices
    
    # Quote freshness requirement (IMMUTABLE)
    # Prices older than this are considered stale and rejected
    MAX_QUOTE_AGE_SECONDS = 5  # Quotes must be fresher than 5 seconds
    
    # Stream management (IMMUTABLE)
    LIVE_STREAM_TIMEOUT_SECONDS = 30  # Disconnect if no data for 30s
    AUTOMATIC_RECONNECT_ON_DISCONNECT = True  # Re-establish connection
    MAX_RECONNECT_ATTEMPTS = 3  # Try 3 times before degrading to practice
    
    @classmethod
    def validate_pin(cls, pin: int) -> bool:
        """Validate PIN for charter access"""
        return pin == cls.PIN
    
    @classmethod
    def validate_timeframe(cls, timeframe: str) -> bool:
        """Validate if timeframe is allowed"""
        # Check if it's in allowed timeframes
        allowed_values = [tf.value for tf in cls.ALLOWED_TIMEFRAMES]
        if timeframe in allowed_values:
            return True
        
        # Explicitly reject forbidden timeframes
        rejected_values = [tf.value for tf in cls.REJECTED_TIMEFRAMES]
        if timeframe in rejected_values:
            return False
        
        # Unknown timeframe - reject by default
        return False
    
    @classmethod
    def validate_hold_duration(cls, hours: float) -> bool:
        """Validate position hold duration"""
        return 0 < hours <= cls.MAX_HOLD_DURATION_HOURS
    
    @classmethod
    def validate_risk_reward(cls, risk_reward_ratio: float) -> bool:
        """Validate risk-reward ratio meets minimum"""
        return risk_reward_ratio >= cls.MIN_RISK_REWARD_RATIO
    
    @classmethod
    def validate_notional(cls, notional_usd: float) -> bool:
        """Validate minimum notional size"""
        return notional_usd >= cls.MIN_NOTIONAL_USD
    
    @classmethod
    def validate_daily_pnl(cls, daily_pnl_pct: float) -> bool:
        """Validate daily PnL hasn't hit breaker"""
        return daily_pnl_pct > cls.DAILY_LOSS_BREAKER_PCT
    
    @classmethod
    def validate(cls, test_key: str = None) -> bool:
        """
        Charter validation test
        Returns True if all charter constants are properly set
        """
        try:
            # Test all core constants exist and are correct type
            assert cls.PIN == 841921, "PIN mismatch"
            assert isinstance(cls.MAX_HOLD_DURATION_HOURS, int), "Hold duration type error"
            assert cls.MAX_HOLD_DURATION_HOURS == 6, "Hold duration value error"
            assert cls.DAILY_LOSS_BREAKER_PCT == -5.0, "Loss breaker error"
            assert cls.MIN_NOTIONAL_USD == 15000, "Notional minimum error"
            assert cls.MIN_RISK_REWARD_RATIO == 3.2, "Risk reward error"
            
            # Test timeframe enforcement
            assert cls.validate_timeframe("M15") == True, "M15 should be allowed"
            assert cls.validate_timeframe("M30") == True, "M30 should be allowed"
            assert cls.validate_timeframe("H1") == True, "H1 should be allowed"
            assert cls.validate_timeframe("M1") == False, "M1 should be rejected"
            assert cls.validate_timeframe("M5") == False, "M5 should be rejected"
            
            # Test validation functions
            assert cls.validate_hold_duration(6) == True, "6h should be valid"
            assert cls.validate_hold_duration(7) == False, "7h should be invalid"
            assert cls.validate_risk_reward(3.2) == True, "3.2 RR should be valid"
            assert cls.validate_risk_reward(3.1) == False, "3.1 RR should be invalid"
            assert cls.validate_notional(15000) == True, "15k should be valid"
            assert cls.validate_notional(14999) == False, "14999 should be invalid"
            assert cls.validate_daily_pnl(-4.9) == True, "-4.9% should be valid"
            assert cls.validate_daily_pnl(-5.1) == False, "-5.1% should hit breaker"
            
            # Test environment-agnostic enforcement
            assert cls.ENVIRONMENT_AGNOSTIC_ENFORCED == True, "Environment-agnostic must be enforced"
            assert cls.ALLOW_ENVIRONMENT_SPECIFIC_LOGIC == False, "Environment-specific logic forbidden"
            assert cls.IDENTICAL_CHARTER_ENFORCEMENT == True, "Charter must be identical across environments"
            
            # Test TP cancellation rules
            assert cls.TP_CANCELLATION_ENABLED == True, "TP cancellation must be enabled"
            assert cls.DISABLE_TP_CANCELLATION == False, "TP cancellation cannot be disabled"
            assert cls.STOP_LOSS_ALWAYS_REQUIRED == True, "Stop loss must always be required"
            assert cls.ALLOW_STOP_LOSS_REMOVAL == False, "Stop loss removal forbidden"
            assert cls.HIVE_TRIGGER_CONFIDENCE_MIN == 0.80, "Hive confidence threshold error"
            assert cls.MOMENTUM_PROFIT_THRESHOLD_ATR == 1.8, "Momentum profit threshold error"
            assert cls.MIN_POSITION_AGE_FOR_TP_CANCEL_SECONDS == 60, "Position age requirement error"
            
            # Test trailing stop levels
            assert cls.TRAILING_LEVEL_1_DISTANCE == 1.2, "Trailing level 1 error"
            assert cls.TRAILING_LEVEL_6_DISTANCE == 0.4, "Trailing level 6 error"
            assert cls.MOMENTUM_TRAIL_LOOSENING_FACTOR == 1.15, "Momentum loosening factor error"
            
            # Test code attribution
            assert cls.MOMENTUM_EXTRACTION_PIN == 841921, "Momentum extraction PIN error"
            assert cls.MOMENTUM_SOURCE_FILE.endswith("rbotzilla_golden_age.py"), "Momentum source file error"
            
            logging.info("RICK Charter validation PASSED ✅")
            return True
            
        except AssertionError as e:
            logging.error(f"RICK Charter validation FAILED: {e}")
            return False
        except Exception as e:
            logging.error(f"RICK Charter validation ERROR: {e}")
            return False
    
    @classmethod
    def get_charter_summary(cls) -> Dict[str, Union[int, float, str, List[str]]]:
        """Return complete charter summary for logging"""
        return {
            "pin": cls.PIN,
            "version": cls.CHARTER_VERSION,
            "max_hold_hours": cls.MAX_HOLD_DURATION_HOURS,
            "daily_loss_breaker": cls.DAILY_LOSS_BREAKER_PCT,
            "min_notional_usd": cls.MIN_NOTIONAL_USD,
            "min_risk_reward": cls.MIN_RISK_REWARD_RATIO,
            "allowed_timeframes": [tf.value for tf in cls.ALLOWED_TIMEFRAMES],
            "rejected_timeframes": [tf.value for tf in cls.REJECTED_TIMEFRAMES],
            "max_concurrent": cls.MAX_CONCURRENT_POSITIONS,
            "max_daily_trades": cls.MAX_DAILY_TRADES
        }

# Charter enforcement on module import
if __name__ == "__main__":
    # Self-test on direct execution
    result = RickCharter.validate("test")
    print(f"Charter Validation: {'PASS' if result else 'FAIL'}")
    if result:
        summary = RickCharter.get_charter_summary()
        print("Charter Summary:", summary)
else:
    # Validate on import
    _validation_result = RickCharter.validate()
    if not _validation_result:
        raise ImportError("RICK Charter validation failed - module import blocked")
