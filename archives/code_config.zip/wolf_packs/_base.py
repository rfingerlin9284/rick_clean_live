"""wolf_packs._base

Simple base class used by smoke tests.
"""

class WolfPackBase:
    """Base class for wolf pack implementations (placeholder)."""

    def __init__(self) -> None:
        self.name = "wolfpack-base"
