RBot Dashboard
===============

Start the Flask dashboard (dev):

```bash
cd dashboard
python3 app.py
```

Then open http://127.0.0.1:8080 to view the headless control panel.

This dashboard can start/stop the tmux headless session. It is intentionally minimal.
